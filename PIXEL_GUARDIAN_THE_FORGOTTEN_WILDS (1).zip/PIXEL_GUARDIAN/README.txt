PIXEL GUARDIAN: THE FORGOTTEN WILDS

Ishga tushirish: index.html faylini Chrome yoki Edge brauzerida ikki marta bosib oching.
Internet va o'rnatish shart emas.

Boshqaruv:
  Strelkalar yoki A/D - yurish
  Probel yoki W - sakrash (havoda yana bir marta bosing: ikkinchi sakrash)
  X yoki Shift - tezlanish (dash)
  Esc - pauza, M - ovozni o'chirish
  Telefonda: ekrandagi tugmalar

Qoidalar:
  - O'yin boshida ismingizni kiritasiz.
  - Har bosqichda 3 ta jon bor. Tuzoq tegsa yoki chuqurga tushsangiz jon ketadi.
  - Jon tugasa bosqich boshidan boshlanadi. Har 20 ta urug' +1 jon beradi (5 tagacha).
  - "?" blokni pastdan boshingiz bilan uring: meva chiqadi. Mevani yesangiz Echo KATTA bo'ladi:
    balandroq sakraydi, dushmanga 2 baravar zarba beradi va bitta zarbani ko'taradi (kichrayadi).
  - Oxiridagi bayroqqa yetsangiz ball, urug', dushman, vaqt va jon bonusi ko'rsatiladi.

Bosqichlar (har biri uzoqroq va qiyinroq):
  1 Greenwood - slime, tikanlar, ko'priklar
  2 Thorn Valley - ilonlar (uzun), tushuvchi toshlar
  3 Frozen Roots - sirpanchiq muz, yo'qoluvchi platformalar, ko'rshapalaklar, boltalar
  4 Sunken Ruins - olov ustunlari, arralar, golemlar (3 marta bosish kerak)
  5 Shadow Swamp - hammasi birga, dushmanlar tezroq va kuchliroq
